const express = require('express');
const bcrypt = require('bcrypt');
const authController = require('../controllers/auth-controller')

const router = express.Router();

router.get('/sign-in',  authController.getSignIn)

router.post('/sign-in', authController.postSignIn)

router.get('/sign-up', authController.getSignUp)

router.post('/sign-up', authController.postSignUp)

router.get('/logout',authController.postLogOut);



module.exports = router;