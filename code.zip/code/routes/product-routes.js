const express = require('express');

const productController = require('../controllers/product-controller');
const categoryController = require('../controllers/category-controller');

const router = express.Router();

router.get('/products', productController.getAllProducts);

router.get('/products/add-product', productController.getAddProduct);
router.post('/products/add-product', productController.postAddProduct);

router.get('/products/edit-product/:id', productController.getEditProduct);
router.post('/products/edit-product/:id', productController.postEditProduct);

router.get('/products/add-category', categoryController.getAddCategory);
router.post('/products/add-category', categoryController.postAddCategory);

router.get('/products/delete/:id', productController.delProduct);


module.exports = router;