const express = require('express');

const router = express.Router();

router.get('/', (req, res, next)=> {
    const isAdmin = req.session?.user?.isAdmin;
    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false; 
    res.render('./index', {
        pageTitle: "Home",
        pageName: 'home',
        isAuthenticated,
        isAdmin,
    });
})

router.get('/home', (req, res, next)=> {
    const isAdmin = req.session?.user?.isAdmin;
    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false; 
    res.render('./index', {
        pageTitle: "Home",
        pageName: 'home',
        isAuthenticated,
        isAdmin,
    });
})

router.get('/about-us', (req, res, next)=> {
    const isAdmin = req.session?.user?.isAdmin;
    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false; 
    res.render('./index', {
        pageTitle: "About Us",
        pageName: 'about-us',
        isAuthenticated,
        isAdmin,
    });
})

router.get('/contact-us', (req, res, next)=> {
    const isAdmin = req.session?.user?.isAdmin;
    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false; 
    res.render('./index', {
        pageTitle: "Contact Us",
        pageName: 'contact-us',
        isAuthenticated,
        isAdmin,
    });
})


module.exports = router;