const ProductModel = require('../models/product-model');
const Category = require('../models/category-model');


exports.getAllProducts = (req, res) => {
    ProductModel.find().then(products => {
        res.render('./index', {
            pageTitle: "Products",
            pageName: 'products',
            products,
        })
    })
}
exports.delProduct = (req, res) => {
    ProductModel.findByIdAndDelete(req.params.id)
    .then(products => {
       res.redirect('/products');
});
}


exports.getAddProduct = (req, res) => {
    Category.find().then(categories => {
        res.render('./index', {
            pageTitle: "Add Product",
            pageName: 'add-product',
            categories,
        })
    })
}

exports.postAddProduct = (req, res) => {
    console.log('hello')
    const product = new ProductModel({
        title: req.body.title,
        price: +req.body.price,
        imageUrl: req.body.imageUrl,
        categoryId: req.body.category
    });
    product.save().then(addedProduct => {
        Category.find().then(categories => {
            res.render('./index', {
                pageTitle: "Add Product",
                pageName: 'add-product',
                categories,
    
            });
        })
    });
}


exports.getEditProduct = (req, res) => {
    ProductModel.find({
            _id: req.params.id
        })
        .then(product => {
            Category.find().then(categories => {
                res.render('./index', {
                    pageTitle: "Edit Product",
                    pageName: 'edit-product',
                    product: product[0],
                    categories,
                    productCategoryId: product[0].categoryId,
                });
            })
        })
}
exports.postEditProduct = (req, res) => {
    const id = req.params.id;
    ProductModel.updateOne({
        id
    }, {
        $set: {
            title: req.body.title,
            price: +req.body.price,
        }
    }).then(product => {
        ProductModel.find({
            _id: req.params.id
        }).then(product => {
            res.render('./index', {
                pageTitle: "Edit Product",
                pageName: 'edit-product',
                product: product[0],
            });
        })
    })
}
