const ProductModel = require('../models/product-model');
const Category = require('../models/category-model');


exports.getAllProducts = (req, res) => {
    const isAdmin = req.session?.user?.isAdmin
    ProductModel.find().then(products => {
        const isAuthenticated = req.session?.isLoggedIn? req.session.isLoggedIn: false;
        res.render('./index', {
            pageTitle: "Products",
            pageName: 'products',
            products,
            isAuthenticated,
            isAdmin
        });
    });
}
exports.delProduct = (req, res) => {
    ProductModel.findByIdAndDelete(req.params.id)
    .then(products => {
       res.redirect('/products');
});
}


exports.getAddProduct = (req, res) => {
    const isAdmin = req.session?.user?.isAdmin
    Category.find().then(categories => {
        res.render('./index', {
            pageTitle: "Add Product",
            pageName: 'add-product',
            categories,
            isAdmin,
        })
    })
}

exports.postAddProduct = (req, res) => {
    const isAdmin = req.session?.user?.isAdmin
    const product = new ProductModel({
        title: req.body.title,
        price: +req.body.price,
        imageUrl: req.body.imageUrl,
        categoryId: req.body.category
    });
    product.save().then(addedProduct => {
        Category.find().then(categories => {
            res.render('./index', {
                pageTitle: "Add Product",
                pageName: 'add-product',
                categories,
                isAdmin,
            });
        })
    });
}


exports.getEditProduct = (req, res) => {
    const isAdmin = req.session?.user?.isAdmin
    ProductModel.find({
            _id: req.params.id
        })
        .then(product => {
            Category.find().then(categories => {
                res.render('./index', {
                    pageTitle: "Edit Product",
                    pageName: 'edit-product',
                    product: product[0],
                    categories,
                    productCategoryId: product[0].categoryId,
                    isAdmin,
                });
            })
        })
}
exports.postEditProduct = async (req, res) => {
    const isAdmin = req.session?.user?.isAdmin
    const categories = await Category.find();
    const id = req.params.id;
    await ProductModel.updateOne(
        {id}, 
        {$set: {
            title: req.body.title,
            price: +req.body.price,
        }
    });
    const product = await ProductModel.find({_id: id})    
    res.render('./index', {
        pageTitle: "Edit Product",
        pageName: 'edit-product',
        product: product[0],
        categories,
        productCategoryId: product[0].categoryId,
        isAdmin,
    });
    
}
