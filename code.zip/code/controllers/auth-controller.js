const { default: mongoose } = require('mongoose');
const authModel = require('../models/auth-model');
const User = require('../models/auth-model')

exports.getSignIn = (req, res) => {
    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn:false;
        res.render('./index', {
            pageTitle: "Sign In",
            pageName: 'sign-in',
            isAuthenticated : isAuthenticated,
        });
}
exports.postSignIn = (req, res) => {
    // res.render('./index', {
    //     pageTitle: "Home",
    //     pageName: 'Home'
    // }); 
    User.findOne({
        email: req.body.email,
        password: req.body.password,
    })
    .then(authModel =>{
        if(authModel){
            req.session.isLoggedIn=ture,
            req.session.user = authModel

            res.redirect('./index')
        }else{
            res.redirect('/auth/sign-in');
        }
    })  
}
exports.getSignUp = (req, res) => {
    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn:false;
    res.render('./index', {
        pageTitle: "Sign Up",
        pageName: 'sign-up', 
        isAuthenticated : isAuthenticated,
    });
}
exports.postSignUp = (req, res) => {
    const user = new User ({
        _id: mongoose.Types.ObjectId(),
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        password: req.body.password,
    })
    user.save().then(user =>{
        res.render('./index', {
            pageTitle: "Home",
            pageName: 'Home'
        });  
    })
}