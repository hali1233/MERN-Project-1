const authModel = require('../models/auth-model');
const User = require('../models/auth-model')
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const saltRounds = 10;

exports.getSignIn = (req, res) => {
    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn:false;
    const isAdmin = req.session?.user?.isAdmin    
        res.render('./index', {
            pageTitle: "Sign In",
            pageName: 'sign-in',
            isAuthenticated : isAuthenticated,
            isAdmin,
        });
}
exports.postSignIn = (req, res) => {
    // res.render('./index', {
    //     pageTitle: "Home",
    //     pageName: 'Home'
    // }); 
    User.findOne({
        email: req.body.email,
        
    })
    .then(authModel =>{
        if(authModel){
            bcrypt.compare(req.body.password, authModel.password)
            .then((response)=>{
                req.session.isLoggedIn = true,
                req.session.user = authModel
                req.user = authModel
                const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false;
                const isAdmin = req.session?.user?.isAdmin
                res.render('./index',{
                    pageTitle:'Home',
                    pageName:'Home',
                    isAuthenticated: isAuthenticated,
                    isAdmin
                });
            }).catch((err)=>{
                console.log("err",err)
               })

        }else{
            res.redirect('/auth/sign-in');
        }
    })  
}
exports.getSignUp = (req, res) => {
    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn:false;
    const isAdmin= req.session?.user?.isAdmin

    res.render('./index', {
        pageTitle: "Sign Up",
        pageName: 'sign-up', 
        isAuthenticated : isAuthenticated,
        isAdmin,
    });
}
exports.postLogOut =(req,res)=>{
    if(req.session){
        res.render('./index',{
            pageTitle: "Home",
            pageName: 'Home',
            isAuthenticated:false,
            isAdmin:false
        });
    }

}
exports.postSignUp = async (req, res) => {
    const salt = await bcrypt.genSalt(10);
    password = await bcrypt.hash(req.body.password, salt);

    const user = new User ({
        _id: mongoose.Types.ObjectId(),
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        password,
        isAdmin: false
    });
    user.save().then(addeduser =>{
       req.session.isLoggedIn=true,
       req.session.user=addeduser
       req.user=addeduser
       const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false; 
       const isAdmin = addeduser.isAdmin;       
       res.render('./index', {
            pageTitle: "Home",
            pageName: 'Home',
            isAuthenticated,
            isAdmin
        });  
    });
}