const User = require('../models/auth-model')

exports.getSignIn = (req, res) => {
        res.render('./index', {
            pageTitle: "Sign In",
            pageName: 'sign-in'
        });
}
exports.postSignIn = (req, res) => {
    res.render('./index', {
        pageTitle: "Home",
        pageName: 'Home'
    }); 
}
exports.getSignUp = (req, res) => {
    res.render('./index', {
        pageTitle: "Sign Up",
        pageName: 'sign-up'
    });
}
exports.postSignUp = (req, res) => {
    const user = new User ({
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        password: req.body.password,
    })
    user.save().then(user =>{
        res.render('./index', {
            pageTitle: "Home",
            pageName: 'Home'
        });  
    })
}