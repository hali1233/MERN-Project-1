const Category = require('../models/category-model');


exports.getAddCategory = (req, res) => {
    res.render('./index',{
      pageTitle:"Add Category",
      pageName:'add-category',
    });

}
exports.postAddCategory = (req, res) => {

    const category = new Category({
        title: req.body.title,
        description: req.body.description,
    });
    category.save().then(addedCategory => {
        res.render('./index', {
            pageTitle: "Add Category",
            pageName: 'add-category',
        })
    })
}