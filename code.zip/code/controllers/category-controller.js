const Category = require('../models/category-model');


exports.getAddCategory = (req, res) => {
    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false; 
    const isAdmin = req.session?.user?.isAdmin;
    res.render('./index',{
      pageTitle:"Add Category",
      pageName:'add-category',
      isAuthenticated,
      isAdmin,
    });

}
exports.postAddCategory = (req, res) => {
    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false; 
    const isAdmin = req.session?.user?.isAdmin;
    const category = new Category({
        title: req.body.title,
        description: req.body.description,
    });
    category.save().then(addedCategory => {
        res.render('./index', {
            pageTitle: "Add Category",
            pageName: 'add-category',
            isAuthenticated,
            isAdmin,
        })
    })
}