const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const mainRouter = require('./routes/main-routes');
const productRouter = require('./routes/product-routes');
const authRouter = require('./routes/auth-routes');
const bodyParser = require('body-parser');
const session = require('express-session');
const MongoDBStore = require('connect-mongodb-session')(session);
const bcrypt = require('bcrypt');


const app = express();
const store = new MongoDBStore({
    uri: 'mongodb://localhost:27017/hexashop-sessions',
    collection: 'sessions',
});

app.use(bodyParser.urlencoded({extended: false}));
app.set('view engine', 'ejs');
app.set('views', 'views');

app.use(
    session({
    secret:'my secret',
    resave: false,
    saveUninitialized:false,
    store:store  
    })
);
app.use(express.static(path.join(__dirname, 'public')));


app.use(mainRouter);
app.use(productRouter);
app.use(authRouter);
app.use('/index',(req,res) => {
    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false;
    const isAdmin= req.session?.user?.isAdmin?true:false
    res.render('index',{
        pageTitle:'Home',
        isAuthenticated: isAuthenticated,
        isAdmin
    });
});

app.use( (req, res, next) => {
    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false;
    res.render('404',{
        pageTitle:'Home',
        isAuthenticated: isAuthenticated
    })

})

const port = 3000;

mongoose.connect('mongodb://localhost:27017/hexashop', () => {
    app.listen(port, () => {
        console.log(`Started listening at port ${port}.`);
    });
});