const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const mainRouter = require('./routes/main-routes');
const productRouter = require('./routes/product-routes');
const authRouter = require('./routes/auth-routes');


const app = express();

const bodyParser = require('body-parser');

app.set('view engine', 'ejs');
app.set('views', 'views');

app.use(bodyParser.urlencoded({extended: false}));
app.use(express.static(path.join(__dirname, 'public')));


app.use(mainRouter);
app.use(productRouter);
app.use(authRouter);

app.use('/',(req, res, next)=>{
    res.send("404");
})

const port = 3000;

mongoose.connect('mongodb://localhost:27017/hexashop', () => {
    app.listen(port, () => {
        console.log(`Started listening at port ${port}.`);
    });
});
